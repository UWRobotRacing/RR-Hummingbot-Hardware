var group__lpuart__freertos__driver =
[
    [ "lpuart_rtos_config_t", "group__lpuart__freertos__driver.html#structlpuart__rtos__config__t", [
      [ "base", "group__lpuart__freertos__driver.html#abf5491a7b9c911ead3f256fc61357f65", null ],
      [ "srcclk", "group__lpuart__freertos__driver.html#a5209f6a860555957f5d75940b2132ae5", null ],
      [ "baudrate", "group__lpuart__freertos__driver.html#a86b9316f7c8bc63e672f7efd09bbb86a", null ],
      [ "parity", "group__lpuart__freertos__driver.html#a77f066eb41ad7b46edd5a3ee9e72d700", null ],
      [ "stopbits", "group__lpuart__freertos__driver.html#a347be0a813260f445e7829308a58f479", null ],
      [ "buffer", "group__lpuart__freertos__driver.html#a355e354365fe669ddf27d8eb538c83e9", null ],
      [ "buffer_size", "group__lpuart__freertos__driver.html#ad8ba8f4845a222fef29714542876ae55", null ]
    ] ],
    [ "FSL_LPUART_FREERTOS_DRIVER_VERSION", "group__lpuart__freertos__driver.html#gae78d379ef6bde2ad08e1fe64f1f09bf5", null ],
    [ "LPUART_RTOS_Init", "group__lpuart__freertos__driver.html#ga5be9370b1fa0187c194475769e7138fc", null ],
    [ "LPUART_RTOS_Deinit", "group__lpuart__freertos__driver.html#ga057e59dcc578ef4b303850bcd90ca50e", null ],
    [ "LPUART_RTOS_Send", "group__lpuart__freertos__driver.html#ga8fa93379ae9896d5f93de86cfeff79d7", null ],
    [ "LPUART_RTOS_Receive", "group__lpuart__freertos__driver.html#ga0561f87122863c6e9b20f8991a73a0fb", null ]
];