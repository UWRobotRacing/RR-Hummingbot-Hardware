var group__pmc =
[
    [ "pmc_low_volt_detect_config_t", "group__pmc.html#structpmc__low__volt__detect__config__t", [
      [ "enableInt", "group__pmc.html#a1b6faa7556a779b18888cb9f21872387", null ],
      [ "enableReset", "group__pmc.html#aea33fece99e8bc969bc44879884b5369", null ]
    ] ],
    [ "pmc_low_volt_warning_config_t", "group__pmc.html#structpmc__low__volt__warning__config__t", [
      [ "enableInt", "group__pmc.html#a78da4196d65b1637b4146336085379ed", null ]
    ] ],
    [ "FSL_PMC_DRIVER_VERSION", "group__pmc.html#ga73519be5675b92701f27a75deec47471", null ],
    [ "PMC_ConfigureLowVoltDetect", "group__pmc.html#ga511f9618f4a4a78c0d18fb1f53ab5256", null ],
    [ "PMC_GetLowVoltDetectFlag", "group__pmc.html#gaa3cfefbdbcc7f124993562db3c13304c", null ],
    [ "PMC_ClearLowVoltDetectFlag", "group__pmc.html#gab96052f58a37d92c00970d4cceaaac48", null ],
    [ "PMC_ConfigureLowVoltWarning", "group__pmc.html#ga711999faa5886861327da2dddadd2277", null ],
    [ "PMC_GetLowVoltWarningFlag", "group__pmc.html#ga76db614fab4fd78577e5e688a609512f", null ],
    [ "PMC_ClearLowVoltWarningFlag", "group__pmc.html#gac98297eab10fd029c18ad28cfe4ff550", null ]
];