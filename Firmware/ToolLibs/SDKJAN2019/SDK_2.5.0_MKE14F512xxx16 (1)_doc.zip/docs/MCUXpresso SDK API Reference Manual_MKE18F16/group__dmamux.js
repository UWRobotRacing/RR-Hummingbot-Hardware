var group__dmamux =
[
    [ "FSL_DMAMUX_DRIVER_VERSION", "group__dmamux.html#ga52b927e4f978ddf42faf0acf6de3df57", null ],
    [ "DMAMUX_Init", "group__dmamux.html#ga850545ac61a004df8ca312db2ca9db73", null ],
    [ "DMAMUX_Deinit", "group__dmamux.html#gab663257d094b9b7b6fa1b894fbf8000b", null ],
    [ "DMAMUX_EnableChannel", "group__dmamux.html#gaecac68802d961c31a06389caa97387f5", null ],
    [ "DMAMUX_DisableChannel", "group__dmamux.html#ga4d68cf7796e4a6a9cd0c4289712ca120", null ],
    [ "DMAMUX_SetSource", "group__dmamux.html#ga97083a74f4af599de628cdd8864d6676", null ],
    [ "DMAMUX_EnablePeriodTrigger", "group__dmamux.html#ga9b873510e45bcc998b5cede12ed359d0", null ],
    [ "DMAMUX_DisablePeriodTrigger", "group__dmamux.html#ga7a632ca1a6bd05a936a4f4ba1295e158", null ]
];