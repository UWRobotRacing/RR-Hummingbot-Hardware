var group__lpspi =
[
    [ "LPSPI FreeRTOS Driver", "group__lpspi__freertos__driver.html", "group__lpspi__freertos__driver" ],
    [ "LPSPI Peripheral driver", "group__lpspi__driver.html", "group__lpspi__driver" ],
    [ "LPSPI eDMA Driver", "group__lpspi__edma__driver.html", "group__lpspi__edma__driver" ]
];