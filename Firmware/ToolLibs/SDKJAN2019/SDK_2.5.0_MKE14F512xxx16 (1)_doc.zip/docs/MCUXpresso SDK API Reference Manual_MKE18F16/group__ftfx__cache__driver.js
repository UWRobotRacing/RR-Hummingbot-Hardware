var group__ftfx__cache__driver =
[
    [ "ftfx_prefetch_speculation_status_t", "group__ftfx__cache__driver.html#structftfx__prefetch__speculation__status__t", [
      [ "instructionOff", "group__ftfx__cache__driver.html#ad51eec780974a727f4f3ba7a0b095838", null ],
      [ "dataOff", "group__ftfx__cache__driver.html#a3023f7f6b09438e65042d22efb0c249a", null ]
    ] ],
    [ "ftfx_cache_config_t", "group__ftfx__cache__driver.html#structftfx__cache__config__t", [
      [ "flashMemoryIndex", "group__ftfx__cache__driver.html#af35a7835817585a789bd936a72779ee9", null ],
      [ "comBitOperFuncAddr", "group__ftfx__cache__driver.html#a95414b5aa04ed8e1ea3b3b024e44716a", null ]
    ] ],
    [ "FSL_FTFX_CACHE_DRIVER_VERSION", "group__ftfx__cache__driver.html#ga03d2543029c1ddce74f55c6ebf83cf93", null ],
    [ "_ftfx_cache_ram_func_constants", "group__ftfx__cache__driver.html#ga94656a81b8ad03c18f8b74dc1a4150d1", [
      [ "kFTFx_CACHE_RamFuncMaxSizeInWords", "group__ftfx__cache__driver.html#gga94656a81b8ad03c18f8b74dc1a4150d1a780ff9cafbfa8b208994881cbe18c182", null ]
    ] ],
    [ "FTFx_CACHE_Init", "group__ftfx__cache__driver.html#ga4615ae98db65653ab1a578eb588d1be4", null ],
    [ "FTFx_CACHE_ClearCachePrefetchSpeculation", "group__ftfx__cache__driver.html#ga9de53487ab56d930f26f14f4410b6f20", null ],
    [ "FTFx_CACHE_PflashSetPrefetchSpeculation", "group__ftfx__cache__driver.html#ga00b01fe1b09708867e1302f35da35e0d", null ],
    [ "FTFx_CACHE_PflashGetPrefetchSpeculation", "group__ftfx__cache__driver.html#gaa1841b33e5241e1a94e54bd35dc58c9e", null ]
];