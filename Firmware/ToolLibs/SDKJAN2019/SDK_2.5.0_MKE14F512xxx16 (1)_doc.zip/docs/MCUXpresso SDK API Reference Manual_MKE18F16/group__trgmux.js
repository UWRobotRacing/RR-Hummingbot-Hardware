var group__trgmux =
[
    [ "FSL_TRGMUX_DRIVER_VERSION", "group__trgmux.html#ga328a23a075a4885fbe9e077344df2c08", null ],
    [ "_trgmux_status", "group__trgmux.html#ga25478c459a35009c6d249e1ba4b5dd96", [
      [ "kStatus_TRGMUX_Locked", "group__trgmux.html#gga25478c459a35009c6d249e1ba4b5dd96a7923504849a10689e4cdcb1e62c1558b", null ]
    ] ],
    [ "trgmux_trigger_input_t", "group__trgmux.html#gaf2f023de74f52a7af5a915a0c5ac37af", [
      [ "kTRGMUX_TriggerInput0", "group__trgmux.html#ggaf2f023de74f52a7af5a915a0c5ac37afa3aff19ab48d4a58f19a23a37ab41693e", null ],
      [ "kTRGMUX_TriggerInput1", "group__trgmux.html#ggaf2f023de74f52a7af5a915a0c5ac37afa44d5bfde0ab0466928fd788848a8798c", null ],
      [ "kTRGMUX_TriggerInput2", "group__trgmux.html#ggaf2f023de74f52a7af5a915a0c5ac37afa0a7d331cc7437f034145829495b60130", null ],
      [ "kTRGMUX_TriggerInput3", "group__trgmux.html#ggaf2f023de74f52a7af5a915a0c5ac37afafb347bd2cc7fa3a396edd5d2b81ec327", null ]
    ] ],
    [ "TRGMUX_LockRegister", "group__trgmux.html#ga5053e8af1807c2b125d3521936801587", null ],
    [ "TRGMUX_SetTriggerSource", "group__trgmux.html#ga000c2133f34743a2738943b3e8359916", null ]
];