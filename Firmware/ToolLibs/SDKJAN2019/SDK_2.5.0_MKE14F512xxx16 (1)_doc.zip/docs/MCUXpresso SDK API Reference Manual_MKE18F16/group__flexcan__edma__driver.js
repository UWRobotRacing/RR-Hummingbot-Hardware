var group__flexcan__edma__driver =
[
    [ "flexcan_edma_handle_t", "group__flexcan__edma__driver.html#struct__flexcan__edma__handle", [
      [ "callback", "group__flexcan__edma__driver.html#a63bbb14985ea667bb86d933782244ebe", null ],
      [ "userData", "group__flexcan__edma__driver.html#a8408c788bc9497c7a74811940a28bce7", null ],
      [ "rxFifoEdmaHandle", "group__flexcan__edma__driver.html#a923894ca8505812ac61ad5632677a7d2", null ],
      [ "rxFifoState", "group__flexcan__edma__driver.html#af08257e6fde0f8f49d152ab07264dfd3", null ]
    ] ],
    [ "FSL_FLEXCAN_EDMA_DRIVER_VERSION", "group__flexcan__edma__driver.html#ga3a725e7f5fd30ef8458220269fbea29f", null ],
    [ "flexcan_edma_transfer_callback_t", "group__flexcan__edma__driver.html#ga200b7c77f4d5b5495193e58772e12c68", null ],
    [ "FLEXCAN_TransferCreateHandleEDMA", "group__flexcan__edma__driver.html#ga1ca334397a0902a09b8b7ddd4a73d87b", null ],
    [ "FLEXCAN_TransferReceiveFifoEDMA", "group__flexcan__edma__driver.html#ga153f2e62a0aff73b242fee109896c34e", null ],
    [ "FLEXCAN_TransferAbortReceiveFifoEDMA", "group__flexcan__edma__driver.html#ga518cce21e8dde19dc32b21a68c549b1b", null ]
];