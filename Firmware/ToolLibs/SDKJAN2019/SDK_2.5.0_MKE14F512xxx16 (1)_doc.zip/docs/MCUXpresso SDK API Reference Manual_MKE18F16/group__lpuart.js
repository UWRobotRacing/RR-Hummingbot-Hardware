var group__lpuart =
[
    [ "LPUART DMA Driver", "group__lpuart__dma__driver.html", "group__lpuart__dma__driver" ],
    [ "LPUART Driver", "group__lpuart__driver.html", "group__lpuart__driver" ],
    [ "LPUART FreeRTOS Driver", "group__lpuart__freertos__driver.html", "group__lpuart__freertos__driver" ],
    [ "LPUART eDMA Driver", "group__lpuart__edma__driver.html", "group__lpuart__edma__driver" ]
];