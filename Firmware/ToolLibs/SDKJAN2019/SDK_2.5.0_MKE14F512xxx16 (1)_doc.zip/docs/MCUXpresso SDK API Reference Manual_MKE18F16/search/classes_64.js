var searchData=
[
  ['dac32_5fbuffer_5fconfig_5ft',['dac32_buffer_config_t',['../group__dac32.html#structdac32__buffer__config__t',1,'']]],
  ['dac32_5fconfig_5ft',['dac32_config_t',['../group__dac32.html#structdac32__config__t',1,'']]],
  ['dmamanager_5fhandle_5ft',['dmamanager_handle_t',['../group__dmamgr.html#structdmamanager__handle__t',1,'']]]
];
