var searchData=
[
  ['crc_5fconfig_5ft',['crc_config_t',['../group__crc.html#structcrc__config__t',1,'']]]
];
