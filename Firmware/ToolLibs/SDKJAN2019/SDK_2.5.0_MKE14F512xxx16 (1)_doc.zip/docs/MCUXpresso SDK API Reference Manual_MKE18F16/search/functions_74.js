var searchData=
[
  ['trgmux_5flockregister',['TRGMUX_LockRegister',['../group__trgmux.html#ga5053e8af1807c2b125d3521936801587',1,'fsl_trgmux.h']]],
  ['trgmux_5fsettriggersource',['TRGMUX_SetTriggerSource',['../group__trgmux.html#ga000c2133f34743a2738943b3e8359916',1,'fsl_trgmux.h']]]
];
