var searchData=
[
  ['offsetmode',['offsetMode',['../group__acmp.html#aa9cf01cde607eb1b8bc1a1315ad990c0',1,'acmp_config_t']]],
  ['outputlogic',['outputLogic',['../group__gpio.html#a9d37ffd9a2943f10a91095759bd52da5',1,'gpio_pin_config_t']]]
];
