var searchData=
[
  ['queue',['queue',['../group__flexio__i2s.html#acb17130610a067da4de5a433dc37c961',1,'_flexio_i2s_handle::queue()'],['../group__flexio__dma__i2s.html#a69b0d0219463b19a52ad666a74270e39',1,'_flexio_i2s_dma_handle::queue()'],['../group__flexio__edma__i2s.html#a8d7523f896a595c8e08b569fe48827eb',1,'_flexio_i2s_edma_handle::queue()']]],
  ['queuedriver',['queueDriver',['../group__flexio__i2s.html#acdd20f95d36162918324befaac2a032a',1,'_flexio_i2s_handle::queueDriver()'],['../group__flexio__dma__i2s.html#a20e1e9fe858a5b0a79a1cfe3db2585c2',1,'_flexio_i2s_dma_handle::queueDriver()'],['../group__flexio__edma__i2s.html#a8652d38a3a09641beee105cfb6d744c3',1,'_flexio_i2s_edma_handle::queueDriver()']]],
  ['queueuser',['queueUser',['../group__flexio__i2s.html#a6cc9e11e1b29e7baa52497f147e95790',1,'_flexio_i2s_handle::queueUser()'],['../group__flexio__dma__i2s.html#a56cb4926e36897c31e9d20b8810b5223',1,'_flexio_i2s_dma_handle::queueUser()'],['../group__flexio__edma__i2s.html#a04c1f185a11c9e9004163b14eb510525',1,'_flexio_i2s_edma_handle::queueUser()']]]
];
