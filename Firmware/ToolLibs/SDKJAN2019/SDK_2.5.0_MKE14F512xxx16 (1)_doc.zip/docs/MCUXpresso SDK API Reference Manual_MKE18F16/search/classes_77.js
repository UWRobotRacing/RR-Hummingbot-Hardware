var searchData=
[
  ['wdog32_5fconfig_5ft',['wdog32_config_t',['../group__wdog32.html#structwdog32__config__t',1,'']]],
  ['wdog32_5fwork_5fmode_5ft',['wdog32_work_mode_t',['../group__wdog32.html#structwdog32__work__mode__t',1,'']]]
];
