var searchData=
[
  ['rcm_3a_20reset_20control_20module_20driver',['RCM: Reset Control Module Driver',['../group__rcm.html',1,'']]],
  ['rtc_3a_20real_20time_20clock',['RTC: Real Time Clock',['../group__rtc.html',1,'']]]
];
