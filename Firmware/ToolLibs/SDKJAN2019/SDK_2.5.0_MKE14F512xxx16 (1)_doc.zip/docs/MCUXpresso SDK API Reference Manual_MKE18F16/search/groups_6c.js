var searchData=
[
  ['lmem_3a_20local_20memory_20controller_20cache_20control_20driver',['LMEM: Local Memory Controller Cache Control Driver',['../group__lmem__cache.html',1,'']]],
  ['lpi2c_3a_20low_20power_20i2c_20driver',['LPI2C: Low Power I2C Driver',['../group__lpi2c.html',1,'']]],
  ['lpi2c_20freertos_20driver',['LPI2C FreeRTOS Driver',['../group__lpi2c__freertos__driver.html',1,'']]],
  ['lpi2c_20master_20driver',['LPI2C Master Driver',['../group__lpi2c__master__driver.html',1,'']]],
  ['lpi2c_20master_20dma_20driver',['LPI2C Master DMA Driver',['../group__lpi2c__master__edma__driver.html',1,'']]],
  ['lpi2c_20slave_20driver',['LPI2C Slave Driver',['../group__lpi2c__slave__driver.html',1,'']]],
  ['lpit_3a_20low_2dpower_20interrupt_20timer',['LPIT: Low-Power Interrupt Timer',['../group__lpit.html',1,'']]],
  ['lpspi_3a_20low_20power_20serial_20peripheral_20interface',['LPSPI: Low Power Serial Peripheral Interface',['../group__lpspi.html',1,'']]],
  ['lpspi_20peripheral_20driver',['LPSPI Peripheral driver',['../group__lpspi__driver.html',1,'']]],
  ['lpspi_20edma_20driver',['LPSPI eDMA Driver',['../group__lpspi__edma__driver.html',1,'']]],
  ['lpspi_20freertos_20driver',['LPSPI FreeRTOS Driver',['../group__lpspi__freertos__driver.html',1,'']]],
  ['lptmr_3a_20low_2dpower_20timer',['LPTMR: Low-Power Timer',['../group__lptmr.html',1,'']]],
  ['lpuart_3a_20low_20power_20uart_20driver',['LPUART: Low Power UART Driver',['../group__lpuart.html',1,'']]],
  ['lpuart_20dma_20driver',['LPUART DMA Driver',['../group__lpuart__dma__driver.html',1,'']]],
  ['lpuart_20driver',['LPUART Driver',['../group__lpuart__driver.html',1,'']]],
  ['lpuart_20edma_20driver',['LPUART eDMA Driver',['../group__lpuart__edma__driver.html',1,'']]],
  ['lpuart_20freertos_20driver',['LPUART FreeRTOS Driver',['../group__lpuart__freertos__driver.html',1,'']]]
];
