var searchData=
[
  ['g_5flpspidummydata',['g_lpspiDummyData',['../group__lpspi__driver.html#ga95e4847cd333277614975d46280df9dd',1,'fsl_lpspi.h']]]
];
