var searchData=
[
  ['notification_20framework',['Notification Framework',['../group__notifier.html',1,'']]]
];
