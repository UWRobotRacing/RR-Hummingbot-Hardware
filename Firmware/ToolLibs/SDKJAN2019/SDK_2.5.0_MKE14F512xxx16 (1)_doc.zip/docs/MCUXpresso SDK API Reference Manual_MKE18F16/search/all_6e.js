var searchData=
[
  ['nbytes',['NBYTES',['../group__edma.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()'],['../group__flexio__edma__camera.html#a12a81c4048e7c1cc3d82b9030631a049',1,'_flexio_camera_edma_handle::nbytes()'],['../group__flexio__edma__i2s.html#a0c4f3ae0b658cf448c53bb0c85859989',1,'_flexio_i2s_edma_handle::nbytes()'],['../group__flexio__edma__spi.html#a32e1ff6188daf9c28eea501cf7585761',1,'_flexio_spi_master_edma_handle::nbytes()'],['../group__flexio__edma__uart.html#a31c522fa133f42dc19a10ce3707a3546',1,'_flexio_uart_edma_handle::nbytes()'],['../group__lpi2c__master__edma__driver.html#a71e19bdaa2d6ed8e95d4b25497a45149',1,'_lpi2c_master_edma_handle::nbytes()'],['../group__lpspi__edma__driver.html#a6cb0ef8b643f0c8da471897277a79e11',1,'_lpspi_master_edma_handle::nbytes()'],['../group__lpspi__edma__driver.html#ac4304fd510994667fcc72cf37ef1345a',1,'_lpspi_slave_edma_handle::nbytes()'],['../group__lpuart__edma__driver.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()']]],
  ['negativeportinput',['negativePortInput',['../group__acmp.html#ad3006796d95290faa4bd142a307085e1',1,'acmp_channel_config_t']]],
  ['nextchanedgemode',['nextChanEdgeMode',['../group__ftm.html#af64561d78c1d94a7d7106785dce6da7c',1,'ftm_dual_edge_capture_param_t']]],
  ['nextswapblockstatus',['nextSwapBlockStatus',['../structftfx__swap__state__config__t.html#aafa39112d05ace3cbd1754e30a9cc7c5',1,'ftfx_swap_state_config_t']]],
  ['notification_20framework',['Notification Framework',['../group__notifier.html',1,'']]],
  ['notifier_5fcallback_5fconfig_5ft',['notifier_callback_config_t',['../group__notifier.html#structnotifier__callback__config__t',1,'']]],
  ['notifier_5fcallback_5ft',['notifier_callback_t',['../group__notifier.html#gafd1d8cc01c496de8b4cd3990ff85415c',1,'fsl_notifier.h']]],
  ['notifier_5fcallback_5ftype_5ft',['notifier_callback_type_t',['../group__notifier.html#gaad75237e3cea51f8315cf6577b35db91',1,'fsl_notifier.h']]],
  ['notifier_5fcreatehandle',['NOTIFIER_CreateHandle',['../group__notifier.html#gaa2dfe33b4724d9c1025acdde1b1b3c31',1,'fsl_notifier.h']]],
  ['notifier_5fgeterrorcallbackindex',['NOTIFIER_GetErrorCallbackIndex',['../group__notifier.html#ga9736632c3beca486ec3f8dab504b839c',1,'fsl_notifier.h']]],
  ['notifier_5fhandle_5ft',['notifier_handle_t',['../group__notifier.html#structnotifier__handle__t',1,'']]],
  ['notifier_5fnotification_5fblock_5ft',['notifier_notification_block_t',['../group__notifier.html#structnotifier__notification__block__t',1,'']]],
  ['notifier_5fnotification_5ftype_5ft',['notifier_notification_type_t',['../group__notifier.html#ga5ee4314c2a52ee0af61985e7163a1be9',1,'fsl_notifier.h']]],
  ['notifier_5fpolicy_5ft',['notifier_policy_t',['../group__notifier.html#ga62e961564dc31b8155d128a3f6566409',1,'fsl_notifier.h']]],
  ['notifier_5fswitchconfig',['NOTIFIER_SwitchConfig',['../group__notifier.html#ga9ca08c8f6fa9a7bafa9ecbe08603cd97',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5fconfig_5ft',['notifier_user_config_t',['../group__notifier.html#gad0b6e919f3ff69992b36a2734a650ec7',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5ffunction_5ft',['notifier_user_function_t',['../group__notifier.html#gacb6a6d6f99e6ddfbb96dae53382949b2',1,'fsl_notifier.h']]],
  ['notifytype',['notifyType',['../group__notifier.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]]
];
