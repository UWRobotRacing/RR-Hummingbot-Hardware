var searchData=
[
  ['edma_5fchannel_5fpreemption_5fconfig_5ft',['edma_channel_Preemption_config_t',['../group__edma.html#structedma__channel__Preemption__config__t',1,'']]],
  ['edma_5fconfig_5ft',['edma_config_t',['../group__edma.html#structedma__config__t',1,'']]],
  ['edma_5fhandle_5ft',['edma_handle_t',['../group__edma.html#structedma__handle__t',1,'']]],
  ['edma_5fminor_5foffset_5fconfig_5ft',['edma_minor_offset_config_t',['../group__edma.html#structedma__minor__offset__config__t',1,'']]],
  ['edma_5ftcd_5ft',['edma_tcd_t',['../group__edma.html#structedma__tcd__t',1,'']]],
  ['edma_5ftransfer_5fconfig_5ft',['edma_transfer_config_t',['../group__edma.html#structedma__transfer__config__t',1,'']]],
  ['ewm_5fconfig_5ft',['ewm_config_t',['../group__ewm.html#structewm__config__t',1,'']]]
];
