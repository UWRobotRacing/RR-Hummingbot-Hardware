var searchData=
[
  ['edma_5fbandwidth_5ft',['edma_bandwidth_t',['../group__edma.html#ga77dde4bf7218f5dff3f5eeeccd565d0f',1,'fsl_edma.h']]],
  ['edma_5fchannel_5flink_5ftype_5ft',['edma_channel_link_type_t',['../group__edma.html#ga9b736ab8d1dd10d8a277712904b29c91',1,'fsl_edma.h']]],
  ['edma_5finterrupt_5fenable_5ft',['edma_interrupt_enable_t',['../group__edma.html#ga345805161c8c8ca55c0866085e3d3f76',1,'fsl_edma.h']]],
  ['edma_5fmodulo_5ft',['edma_modulo_t',['../group__edma.html#ga13ac7c9e76c11d3dce06f8976d9e4dd7',1,'fsl_edma.h']]],
  ['edma_5ftransfer_5fsize_5ft',['edma_transfer_size_t',['../group__edma.html#gafeb85400b3b87188983f5d62e9e26cb6',1,'fsl_edma.h']]],
  ['edma_5ftransfer_5ftype_5ft',['edma_transfer_type_t',['../group__edma.html#ga7803399034b374663f76a589da7d8419',1,'fsl_edma.h']]]
];
