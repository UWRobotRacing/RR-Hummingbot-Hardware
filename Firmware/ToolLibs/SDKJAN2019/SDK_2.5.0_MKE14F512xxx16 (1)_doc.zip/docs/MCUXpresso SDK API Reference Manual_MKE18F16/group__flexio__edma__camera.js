var group__flexio__edma__camera =
[
    [ "flexio_camera_edma_handle_t", "group__flexio__edma__camera.html#struct__flexio__camera__edma__handle", [
      [ "callback", "group__flexio__edma__camera.html#aa6a47749cad9e09b544d2a4038b6e420", null ],
      [ "userData", "group__flexio__edma__camera.html#ad1efb23fc99dcbde281ccca7fcbe5d1f", null ],
      [ "rxSize", "group__flexio__edma__camera.html#a9560b4e1d59b1cce760c8a49616ee5a4", null ],
      [ "rxEdmaHandle", "group__flexio__edma__camera.html#a9cc34504566bb70be81ce06129c45988", null ],
      [ "nbytes", "group__flexio__edma__camera.html#a12a81c4048e7c1cc3d82b9030631a049", null ],
      [ "rxState", "group__flexio__edma__camera.html#a4e5b67ad139f90a05551fe80506c8df9", null ]
    ] ],
    [ "FSL_FLEXIO_CAMERA_EDMA_DRIVER_VERSION", "group__flexio__edma__camera.html#ga52394c208ce319682c96e0f1516e57fb", null ],
    [ "flexio_camera_edma_transfer_callback_t", "group__flexio__edma__camera.html#gabb60fe8b364fd7236b89905639ea4b0c", null ],
    [ "FLEXIO_CAMERA_TransferCreateHandleEDMA", "group__flexio__edma__camera.html#gafcfbdd57ed04df3dc16ef839c1b94b36", null ],
    [ "FLEXIO_CAMERA_TransferReceiveEDMA", "group__flexio__edma__camera.html#ga0d33545dd2a68785b201ab14903cd93f", null ],
    [ "FLEXIO_CAMERA_TransferAbortReceiveEDMA", "group__flexio__edma__camera.html#ga91a874d217607acf9d91cc6a63b65b83", null ],
    [ "FLEXIO_CAMERA_TransferGetReceiveCountEDMA", "group__flexio__edma__camera.html#ga746d3fa2b5f984e00b35bf1cc338e053", null ]
];