var group__lpspi__freertos__driver =
[
    [ "FSL_LPSPI_FREERTOS_DRIVER_VERSION", "group__lpspi__freertos__driver.html#gaf5602bf29f89af865ebea200ff535f98", null ],
    [ "LPSPI_RTOS_Init", "group__lpspi__freertos__driver.html#ga17e5f827d714b4bba86af6ce5b9e8119", null ],
    [ "LPSPI_RTOS_Deinit", "group__lpspi__freertos__driver.html#gadac220234f10116e78dd6ce341c4377c", null ],
    [ "LPSPI_RTOS_Transfer", "group__lpspi__freertos__driver.html#gad1bc18b3a105852cfcea1f5fc97ef0d8", null ]
];